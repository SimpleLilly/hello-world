import urllib
import urllib2
url = "http://localhost:8080/cgi-bin/testcgi.py?ServiceCode=99999"
req = urllib2.Request(url)
# print req
res_data = urllib2.urlopen(req)
res = res_data.read()
print res
