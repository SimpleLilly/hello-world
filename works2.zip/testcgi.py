#!C:\Python27\python.exe
#encoding:gb2312

import cgi
def main(): 
  print "Content-type: text/html\n"
  form = cgi.FieldStorage()
  if form.has_key("ServiceCode") and form["ServiceCode"].value != "":
    print "BUILD_ID=",form["ServiceCode"].value
  else:  
    print "Error!"
main()
