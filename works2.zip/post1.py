import urllib
import urllib2
test_data = {'ServiceCode':'67890'}
test_data_urlencode = urllib.urlencode(test_data)
requrl = "http://localhost:8080/cgi-bin/testcgi.py"
req = urllib2.Request(url = requrl,data =test_data_urlencode)
#print req
res_data = urllib2.urlopen(req)
res = res_data.read()
print res
