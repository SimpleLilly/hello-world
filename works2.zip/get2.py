import httplib
url = "http://localhost:8080/cgi-bin/testcgi.py?ServiceCode=99999"
conn = httplib.HTTPConnection("localhost:8080")
conn.request(method="GET",url=url) 
response = conn.getresponse()
res= response.read()
print res
