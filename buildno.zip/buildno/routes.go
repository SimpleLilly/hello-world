package main

import (
    "fmt"
//    "time"
    "encoding/json"
    "io"
    "log"
    "net/http"
	"strconv"
	"os"
)

type Result struct {
    Buildno string `json:"buildno"`
}

type handler func(w http.ResponseWriter, r *http.Request)

func HandlePostConsumeBuildno(w http.ResponseWriter, r *http.Request) {
    r.ParseForm()

    w.Header().Set("Content-Type", "application/json")

	Buildno++
	BuildnoStr := strconv.Itoa(Buildno)
	
	f, err := os.Create("buildno.txt")
	if err != nil {
        panic(err)
    }

	_, err = f.WriteString(BuildnoStr)

	f.Close()
	
    result, _ := json.Marshal(Result{BuildnoStr})
    io.WriteString(w, string(result))

		
    var text string
//    text = fmt.Sprintf(time.Now().Format(time.RFC850))
//    log.Println(text)

	text = fmt.Sprintf("consume_buildno: %v", BuildnoStr)
    log.Println(text)
}
