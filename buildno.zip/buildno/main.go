package main

import (
    "log"
    "net/http"
    "io/ioutil"
	"strconv"
)

var Buildno int

func main() {

    data, err := ioutil.ReadFile("buildno.txt")
    if err != nil {
        panic(err)
    }
 
    Buildno, err = strconv.Atoi(string(data))

    http.HandleFunc("/v1/consume_buildno", PostOnly(HandlePostConsumeBuildno))
    
    log.Fatal(http.ListenAndServe(":8080", nil))
}
